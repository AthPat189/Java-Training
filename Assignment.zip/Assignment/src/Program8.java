
public class Program8 {

	public static void main(String[] args) {
	     int[] a = {55, 45, 69, 44};
	      int num = 55;

	      for(int i = 0; i<a.length; i++){
	         if(num == a[i]){
	            System.out.println("Array contains the given element");
	         }
	      }
	   

	}

}

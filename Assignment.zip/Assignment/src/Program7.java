
public class Program7 {

	public static void main(String[] args) {
		
		
		  char ch= 'a';
	      String str = Character.toString(ch);
	      System.out.println("String is: "+str);
	      
	      String str1 = "Hello";
	      for(int i=0; i<str1.length();i++){
	        char ch1 = str1.charAt(i);
	        System.out.println("Character at "+i+" Position: "+ch1);
	      } 
	      

	}

}
